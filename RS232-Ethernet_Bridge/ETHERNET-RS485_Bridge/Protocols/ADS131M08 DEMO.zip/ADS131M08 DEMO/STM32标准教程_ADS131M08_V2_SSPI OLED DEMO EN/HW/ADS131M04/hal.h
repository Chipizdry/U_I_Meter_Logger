/**
 * \copyright Copyright (C) 2019 Texas Instruments Incorporated - http://www.ti.com/
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef INTERFACE_H_
#define INTERFACE_H_

#include "ads131m0x.h"
#include "SysTick.h"

//****************************************************************************
//
// Standard libraries
//
//****************************************************************************

#include <stdbool.h>
#include <stdint.h>

#include "stm32f10x.h"
#include "stdio.h"


//****************************************************************************
//
// Insert processor specific header file(s) here
//
//****************************************************************************

/*  --- INSERT YOUR CODE HERE --- */
//#include "ti/devices/msp432e4/driverlib/driverlib.h"



//****************************************************************************
//
// LaunchPad pinout...
//
//****************************************************************************
/*
	ͨ���Ű�������
      ADS131M04ģ��    STM32F103C6/C8������
      
      SYNC/RST    <------  PA1  PB1    SYNC/��λ�ź�
      CS          <------  PA4         SPI_CS
      DRDY        ------>  PA3  PB0    ׼������
      SCLK        <------  PA5      SPIʱ��
      DOUT        ------>  PA6      SPI_MISO
      DIN         <------  PA7      SPI_MOSI
      CLKIN       <------  PA8      ʱ���źţ�ע�⣬STM��PA8��MCO��������Ų���
*/


//*****************************************************************************
//
// Pin definitions 
//
//*****************************************************************************

	/* ����GPIO�˿� */
  #define RCC_SYNC 	RCC_APB2Periph_GPIOB
	#define PORT_SYNC	GPIOB
	#define PIN_SYNC	GPIO_Pin_1

	#define RCC_CS 		RCC_APB2Periph_GPIOA
	#define PORT_CS		GPIOA
	#define PIN_CS		GPIO_Pin_4

	#define RCC_DRDY 	RCC_APB2Periph_GPIOB
	#define PORT_DRDY	GPIOB
	#define PIN_DRDY	GPIO_Pin_0
  
  #define RCC_SCK 	RCC_APB2Periph_GPIOA
	#define PORT_SCK	GPIOA
	#define PIN_SCK		GPIO_Pin_5
  
  #define RCC_DOUT 	RCC_APB2Periph_GPIOA
	#define PORT_DOUT	GPIOA
	#define PIN_DOUT	GPIO_Pin_6

	#define RCC_DIN 	RCC_APB2Periph_GPIOA
	#define PORT_DIN	GPIOA
	#define PIN_DIN		GPIO_Pin_7
  
  #define RCC_CLKIN 	RCC_APB2Periph_GPIOA
	#define PORT_CLKIN	GPIOA
	#define PIN_CLKIN		GPIO_Pin_8

// (OPTIONAL) External clock source
//#define CLKIN_PORT          (GPIO_PORTG_BASE)
//#define CLKIN_PIN           (GPIO_PIN_1)

/* ���������0����1�ĺ� */

	#define SYNC_0()		GPIO_ResetBits(PORT_SYNC, PIN_SYNC)
	#define SYNC_1()		GPIO_SetBits(PORT_SYNC, PIN_SYNC)

	#define CS_0()		GPIO_ResetBits(PORT_CS, PIN_CS)
	#define CS_1()		GPIO_SetBits(PORT_CS, PIN_CS)

	#define SCK_0()		GPIO_ResetBits(PORT_SCK, PIN_SCK)
	#define SCK_1()		GPIO_SetBits(PORT_SCK, PIN_SCK)

	#define DI_0()		GPIO_ResetBits(PORT_DIN, PIN_DIN)
	#define DI_1()		GPIO_SetBits(PORT_DIN, PIN_DIN)

	#define DO_IS_HIGH()	(GPIO_ReadInputDataBit(PORT_DOUT, PIN_DOUT) == Bit_SET)

	#define DRDY_IS_LOW()	(GPIO_ReadInputDataBit(PORT_DRDY, PIN_DRDY) == Bit_RESET)

//*****************************************************************************
//
// Function Prototypes
//
//*****************************************************************************

void    InitADC(void);
static void SysCtlDelay(uint32_t ui32Count);
//void    delay_ms(const uint32_t delay_time_ms);
//void    delay_us(const uint32_t delay_time_us);
void    setCS(const bool state);
void    setSYNC_RESET(const bool state);
void    toggleSYNC(void);
void    toggleRESET(void);
void    spiSendReceiveArrays(const uint8_t DataTx[], uint8_t DataRx[], const uint8_t byteLength);
uint8_t spiSendReceiveByte(const uint8_t dataTx);
bool    waitForDRDYinterrupt(const uint32_t timeout_ms);

// Functions used for testing only
bool    getCS(void);
bool    getSYNC_RESET(void);
void    setSYNC_RESET(const bool state);

void ADS131m0x_StartScan();
void EXTI0_IRQHandler(void);
void ADS131m0x_ISR(void);
int32_t ADS131m0x_GetAdc(int32_t iTemp[8]);


//*****************************************************************************
//
// Macros
//
//*****************************************************************************
/** Alias used for setting GPIOs pins to the logic "high" state */
#define HIGH                ((bool) true)

/** Alias used for setting GPIOs pins to the logic "low" state */
#define LOW                 ((bool) false)



#endif /* INTERFACE_H_ */
