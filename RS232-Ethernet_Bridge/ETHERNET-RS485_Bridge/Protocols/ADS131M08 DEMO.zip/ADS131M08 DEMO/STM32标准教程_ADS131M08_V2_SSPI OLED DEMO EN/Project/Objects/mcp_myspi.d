.\objects\mcp_myspi.o: ..\HW\ADS131M04\mcp_myspi.c
.\objects\mcp_myspi.o: ..\HW\ADS131M04\mcp_myspi.h
