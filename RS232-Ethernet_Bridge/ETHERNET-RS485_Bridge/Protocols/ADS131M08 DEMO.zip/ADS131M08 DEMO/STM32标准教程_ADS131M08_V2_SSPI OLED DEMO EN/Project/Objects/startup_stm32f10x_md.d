.\objects\startup_stm32f10x_md.o: ..\ARM\System\startup_stm32f10x_md.s
